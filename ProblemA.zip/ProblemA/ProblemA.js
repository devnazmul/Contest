const fs = require("fs");

// PATH OF THE INPUT FILE
const filePath = "input.txt";

// FUNCTION FOR READ INPUT FROM TEXT FILE
const readFile = (filePath) => {
  return fs.readFileSync(filePath, "utf8").split(" ").map(Number);
};

try {
  const numbers = readFile(filePath);
  const pivot = numbers[0];

  const lessThanPivot = [];
  const equalToPivot = pivot;
  const greaterThanPivot = [];

  for (let i = 1; i < numbers.length; i++) {
    if (numbers[i] < pivot) {
      // GET NUMBERS THOSE ARE LESS THAN PIVOT AND STORE THEM IN AN ARRAY
      lessThanPivot.push(numbers[i]);
    } else if (numbers[i] > pivot) {
      // GET NUMBERS THOSE ARE GREATER THAN PIVOT AND STORE THEM IN AN ARRAY
      greaterThanPivot.push(numbers[i]);
    }
  }

  // OUTPUTS
  console.log(
    `${lessThanPivot.join(" ")} ${equalToPivot} ${greaterThanPivot.join(" ")}`
  );
} catch (error) {
  // IF THERE IS AN ERROR
  console.error("Error reading the file:", error);
}
